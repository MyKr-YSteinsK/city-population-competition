# S1 Final Review Pack Manifest

This pack contains only current S1 truth and machine-readable contract/quality registries.
It excludes historical Plan01-04 reports and all modeling or validation artifacts.

| member | bytes | sha256 |
|---|---:|---|
| `CODEX_INSTRUCTIONS.md` | 1613 | `a545317c7f70bc221e2cc173e98d5bbb3a29ae49904026d3493a36e98fbe86d5` |
| `PROJECT_CONTEXT.md` | 2693 | `4f902d64a0dd48954a557fb24e379afab9625d7eb3153901770b8bb8e01a0254` |
| `PROJECT_FILE_MAP.md` | 3544 | `3fa44403f817f6084b761f88837bc4e7e5522bf06d2809b056b94b77243cb7a0` |
| `README.md` | 899 | `21ec4923be1cc8d602181904b059be47bf42deb5544b777e2ca4efbeed1f4fe8` |
| `S1_DATA_CONTRACT.md` | 1361 | `6009264283d17381261200e7b40d0e9e7b0f58e7eed9e2168ee17700a4476958` |
| `S1_FINAL_STATE.md` | 1286 | `153debce4c9b78c200f47f609a7ee940f47b04853f7d228732cdb0339dff7e93` |
| `S1_MAIN_HANDOFF.md` | 1371 | `84d9f3864ea1cb816a32a9e52f90dfc5979fba2b6ce2b5ade9ba352b2aa68e71` |
| `s1_data_contract.csv` | 12626 | `d07f327d3570d9ba931e804b792b46e91cff480a513c41100b217523d5c36630` |
| `s1_quality_issue_registry.csv` | 3036 | `a811820bc0d1561aacc4c03bb9ec0bffca47033ded5593993dfc8ee9302870e1` |
