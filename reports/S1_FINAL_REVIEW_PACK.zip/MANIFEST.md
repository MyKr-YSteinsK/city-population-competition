# S1 Final Review Pack Manifest

This pack contains only current S1 truth and machine-readable contract/quality registries.
It excludes historical Plan01-04 reports and all modeling or validation artifacts.

| member | bytes | sha256 |
|---|---:|---|
| `CODEX_INSTRUCTIONS.md` | 1306 | `e117d4257cc99f0929b862b6eca38a9ce127f8af30978bc4e96a20031059f394` |
| `PROJECT_CONTEXT.md` | 1655 | `9c9790eee553017c75f1136d4b45a0f0f979115920cbbfd035dd87aa9853c73b` |
| `PROJECT_FILE_MAP.md` | 1316 | `55e4195e5b568b103844d85e4ce20b2c41ca263b41d989e32b6a8666570846d4` |
| `README.md` | 765 | `d8cf55d69587f9a27fa2e32b0680efd818b36d3fe59497d64810168ced145d56` |
| `S1_DATA_CONTRACT.md` | 1361 | `6009264283d17381261200e7b40d0e9e7b0f58e7eed9e2168ee17700a4476958` |
| `S1_FINAL_STATE.md` | 1286 | `153debce4c9b78c200f47f609a7ee940f47b04853f7d228732cdb0339dff7e93` |
| `S1_MAIN_HANDOFF.md` | 1371 | `84d9f3864ea1cb816a32a9e52f90dfc5979fba2b6ce2b5ade9ba352b2aa68e71` |
| `s1_data_contract.csv` | 12626 | `d93a0fbcbafc5f1f63160f22c8d4abe68ee4021b7a41de4a134e5f261287eb16` |
| `s1_quality_issue_registry.csv` | 3036 | `628bd52c04d914bddd0c79d13751fbe65b0421e42b4a527541d33dcb63d036df` |
